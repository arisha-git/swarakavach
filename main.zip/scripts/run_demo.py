"""CLI finale-demo rehearsal: enroll the 'regional manager', then run four calls.

Call 1 — genuine manager    → LOW      → transaction proceeds
Call 2 — cloned manager     → CRITICAL → HOLD + liveness challenge + supervisor
Call 3 — TTS attacker (EN)  → CRITICAL → all actions (SSL layer misses it; layer A catches)
Call 4 — TTS attacker (HI)  → CRITICAL → multilingual; ASR feeds Hindi intent rules

Transcripts come from LIVE ASR (whisper, GPU) — no hardcoded text; the demo
shows the production transcript path, including its noise on TTS Hindi.

Usage: python scripts/run_demo.py [--scenario-dir data/demo/scenario]
"""
import argparse
from pathlib import Path

import numpy as np

from swarakavach import asr as asr_mod
from swarakavach import config
from swarakavach.audio import iter_chunks, load_wav
from swarakavach.detectors import artifact, context as ctx_engine, intent, speaker, ssl_detector
from swarakavach.fusion import RiskEngine

CTX = {"caller_id_match": "false", "enrolled_contact": "true", "tx_amount": 5_000_000}

BREAKDOWN_LABELS = [
    ("voice_authenticity_risk", "voice authenticity"),
    ("speaker_mismatch_risk", "speaker mismatch  "),
    ("call_context_risk", "call context      "),
    ("social_engineering_risk", "social engineering"),
]


def call(name: str, wav_path: Path, speaker_id: str) -> RiskEngine:
    engine = RiskEngine(dict(CTX))
    print(f"\n-- incoming call: {name} ({wav_path.name}) --")
    wav = load_wav(wav_path)
    transcript = None
    if asr_mod.available():
        transcript = asr_mod.transcribe(wav) or None
    if transcript:
        ix = intent.explain(transcript)
        print(f"  ASR heard: {ix and transcript[:80]}")
        print(f"  intent rules: {ix['matched'] or 'none'}")
    else:
        print("  (ASR unavailable — intent layer abstains)")
    for i, chunk in enumerate(iter_chunks(wav), 1):
        ev = engine.update({
            "artifact": artifact.score(chunk),
            "ssl": ssl_detector.score(chunk),
            "speaker": speaker.score(speaker_id, chunk),
            "context": ctx_engine.score(engine.context),
            "intent": intent.score(transcript),
        })
        bar = "#" * int(ev["risk"] * 40)
        print(f"  chunk {i:02d}  risk={ev['risk']:.3f} [{bar:<40}] {ev['level']}")
    v = engine.verdict()
    print(f"  VERDICT: level={v['level']} risk_final={v['risk_final']} peak={v['risk_peak']}")
    print(f"  actions: {', '.join(v['actions']) or 'none -- transaction proceeds'}")
    print("  why (explainable breakdown, 0-100 risk):")
    for key, label in BREAKDOWN_LABELS:
        val = v["breakdown"].get(key)
        if val is not None:
            print(f"    {label:<20} {val:3d}  {'#' * (val // 5)}")
    print(f"    {'FINAL RISK':<20} {int(round(v['risk_peak'] * 100)):3d}  "
          f"{'#' * int(v['risk_peak'] * 20)}  [{v['level']}]")
    return engine


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario-dir", default=str(config.DATA_DIR / "demo" / "scenario"))
    ap.add_argument("--speaker-id", default="regional_manager")
    args = ap.parse_args()
    sd = Path(args.scenario_dir)
    real, clone = sd / "manager_real.wav", sd / "manager_clone.wav"
    if not (real.exists() and clone.exists()):
        raise SystemExit("scenario files missing -- run scripts/make_demo_data.py first")

    print("enrolling regional manager voiceprint ...")
    speaker.enroll(args.speaker_id, load_wav(real))
    print("layers:", f"artifact={artifact.available()}", f"ssl={ssl_detector.available()}")

    calls = [("genuine", "genuine manager", real),
             ("cloned", "CLONED manager (XTTS zero-shot)", clone)]
    attacker, hindi = sd / "attacker_tts.wav", sd / "attacker_hindi.wav"
    if attacker.exists():
        calls.append(("attacker_en", "TTS ATTACKER (English)", attacker))
    if hindi.exists():
        calls.append(("attacker_hi", "TTS ATTACKER (Hindi)", hindi))

    engines = {}
    for key, name, path in calls:
        engines[key] = call(name, path, args.speaker_id)

    peaks = {k: max(e.trajectory) for k, e in engines.items()}
    medians = {k: float(np.median(e.trajectory)) for k, e in engines.items()}
    print(f"\npeaks:   { {k: round(v, 3) for k, v in peaks.items()} }")
    print(f"medians: { {k: round(v, 3) for k, v in medians.items()} }")
    # the median-robust verdict is the system's real decision rule: a single
    # glitchy chunk (e.g. a musical opening fanfare) must not read as an attack
    ok = medians["cloned"] > medians["genuine"] + 0.1
    print(f"{'PASS' if ok else 'FAIL'}: clone median {medians['cloned']:.3f} "
          f"vs genuine median {medians['genuine']:.3f}")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
